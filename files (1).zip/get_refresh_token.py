"""
setup/get_refresh_token.py
──────────────────────────
Script da eseguire UNA SOLA VOLTA in locale per ottenere il refresh token Gmail.
Dopo averlo eseguito, copia i valori nei GitHub Secrets.

Prerequisiti:
  pip install google-auth-oauthlib

Istruzioni:
  1. Vai su https://console.cloud.google.com/
  2. Crea un nuovo progetto (es. "macro-grisa-briefing")
  3. Abilita "Gmail API" nella sezione Library
  4. Vai su "Credentials" → "Create Credentials" → "OAuth 2.0 Client ID"
  5. Tipo applicazione: "Desktop App"
  6. Scarica il file JSON e rinominalo "credentials.json"
  7. Metti credentials.json nella stessa cartella di questo script
  8. Esegui: python setup/get_refresh_token.py
"""

import json
import sys
from pathlib import Path

try:
    from google_auth_oauthlib.flow import InstalledAppFlow
except ImportError:
    print("Errore: installa prima le dipendenze:")
    print("  pip install google-auth-oauthlib")
    sys.exit(1)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
]

CREDENTIALS_FILE = Path(__file__).parent / "credentials.json"


def main():
    print("=" * 60)
    print("   MACRO GRISA — Setup Gmail OAuth")
    print("=" * 60)

    if not CREDENTIALS_FILE.exists():
        print(f"\n❌ File non trovato: {CREDENTIALS_FILE}")
        print("\nSeguire queste istruzioni:")
        print("  1. Vai su: https://console.cloud.google.com/")
        print("  2. Crea progetto → Abilita Gmail API")
        print("  3. Credentials → OAuth 2.0 Client ID → Desktop App")
        print("  4. Scarica il JSON → rinominalo 'credentials.json'")
        print(f"  5. Spostalo in: {CREDENTIALS_FILE.parent}/")
        sys.exit(1)

    print("\n✓ credentials.json trovato")
    print("\nSi aprirà il browser per autorizzare l'accesso Gmail...")
    print("Accetta con l'account grisantelli@gmail.com\n")

    flow = InstalledAppFlow.from_client_secrets_file(str(CREDENTIALS_FILE), SCOPES)
    creds = flow.run_local_server(port=0, prompt="consent")

    print("\n" + "=" * 60)
    print("✅  AUTORIZZAZIONE COMPLETATA")
    print("=" * 60)
    print("\nCopia questi valori nei GitHub Secrets del tuo repository:")
    print("(Settings → Secrets and variables → Actions → New repository secret)\n")

    print(f"Secret name: GMAIL_CLIENT_ID")
    print(f"Secret value:\n  {creds.client_id}\n")

    print(f"Secret name: GMAIL_CLIENT_SECRET")
    print(f"Secret value:\n  {creds.client_secret}\n")

    print(f"Secret name: GMAIL_REFRESH_TOKEN")
    print(f"Secret value:\n  {creds.refresh_token}\n")

    # Salva anche su file locale per riferimento
    output = {
        "GMAIL_CLIENT_ID": creds.client_id,
        "GMAIL_CLIENT_SECRET": creds.client_secret,
        "GMAIL_REFRESH_TOKEN": creds.refresh_token,
    }
    out_path = Path(__file__).parent / "tokens_output.json"
    out_path.write_text(json.dumps(output, indent=2))
    print(f"(Salvati anche in: {out_path} — NON committare questo file!)")
    print("\n⚠️  Aggiungi tokens_output.json al .gitignore")


if __name__ == "__main__":
    main()
