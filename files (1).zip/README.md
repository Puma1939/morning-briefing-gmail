# 🗞 Macro Grisa Daily Briefing
> Briefing quotidiano automatico da Bloomberg · Barron's · WSJ via GitHub Actions + Claude API

---

## Come funziona

```
[GitHub Actions cron 7:30]
        ↓
  src/main.py
        ↓
  Gmail API → legge email Bloomberg/Barrons/WSJ (ultime 24h)
        ↓
  Claude API (claude-haiku) → genera briefing HTML in italiano
        ↓
  Gmail API → invia email a grisantelli@gmail.com
```

---

## Setup (una tantum, ~15 minuti)

### STEP 1 — Crea il repository GitHub

1. Vai su [github.com/new](https://github.com/new)
2. Nome repository: `macro-grisa-briefing`
3. **Private** (consigliato)
4. Crea il repository

### STEP 2 — Carica i file

Copia in ordine tutti i file di questo progetto nel repository:
```
macro-grisa-briefing/
├── .github/workflows/daily_briefing.yml
├── src/main.py
├── setup/get_refresh_token.py
├── requirements.txt
└── .gitignore
```

### STEP 3 — Ottieni l'API key di Anthropic

1. Vai su [console.anthropic.com](https://console.anthropic.com)
2. **API Keys** → **Create Key**
3. Copia la chiave (inizia con `sk-ant-...`)

### STEP 4 — Configura Google Cloud per Gmail

1. Vai su [console.cloud.google.com](https://console.cloud.google.com/)
2. **Crea un nuovo progetto** → nome: `macro-grisa-briefing`
3. Menu laterale → **APIs & Services** → **Library**
4. Cerca "Gmail API" → **Enable**
5. **Credentials** → **Create Credentials** → **OAuth 2.0 Client ID**
6. Tipo applicazione: **Desktop app** → nome: `briefing-script`
7. **Download JSON** → rinomina il file `credentials.json`

### STEP 5 — Ottieni il Refresh Token (esegui in locale)

Sul tuo Mac/PC:
```bash
# Clona il repository
git clone https://github.com/TUO_USERNAME/macro-grisa-briefing
cd macro-grisa-briefing

# Installa dipendenze
pip install google-auth-oauthlib

# Copia credentials.json nella cartella setup/
cp ~/Downloads/credentials.json setup/credentials.json

# Esegui lo script di setup
python setup/get_refresh_token.py
```

Si aprirà il browser → accedi con **grisantelli@gmail.com** → autorizza.

Lo script stamperà 3 valori: `GMAIL_CLIENT_ID`, `GMAIL_CLIENT_SECRET`, `GMAIL_REFRESH_TOKEN`.

### STEP 6 — Aggiungi i GitHub Secrets

Nel repository GitHub: **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

Aggiungi questi 4 secret:

| Nome | Valore |
|------|--------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` (dall'STEP 3) |
| `GMAIL_CLIENT_ID` | (dall'STEP 5) |
| `GMAIL_CLIENT_SECRET` | (dall'STEP 5) |
| `GMAIL_REFRESH_TOKEN` | (dall'STEP 5) |

### STEP 7 — Test manuale

Nel repository GitHub:
**Actions** → **🗞 Macro Grisa Daily Briefing** → **Run workflow** → **Run workflow**

Controlla i log e verifica che arrivi l'email.

---

## Orario di invio

Il briefing viene inviato alle **7:30 ora italiana**:

```yaml
# Estate (CEST = UTC+2): 7:30 = 05:30 UTC
- cron: '30 5 * * 1-5'

# Inverno (CET = UTC+1): 7:30 = 06:30 UTC
# → Cambia in: '30 6 * * 1-5'
```

Attivo **Lunedì–Venerdì** (`1-5`). Per includere il weekend: `1-7`.

---

## Costi stimati

| Voce | Costo mensile |
|------|--------------|
| GitHub Actions (private repo) | ~1 min/giorno × 22gg = **gratuito** (entro 2000 min/mese) |
| Claude Haiku (input ~8k tok + output ~4k tok) | ~$0.006/giorno = **~$0.13/mese** |
| Gmail API | **gratuito** |
| **Totale** | **~$0.15/mese** |

---

## Troubleshooting

**Il token scade (raro, ogni 6 mesi):**
Riesegui `python setup/get_refresh_token.py` e aggiorna il secret `GMAIL_REFRESH_TOKEN`.

**Nessuna email trovata:**
Verifica che le newsletter di Bloomberg/Barrons/WSJ vengano consegnate a grisantelli@gmail.com
e non finiscano nello spam.

**Errore 403 Gmail:**
Vai su Google Cloud Console → OAuth consent screen → verifica che `grisantelli@gmail.com`
sia nella lista "Test users".
