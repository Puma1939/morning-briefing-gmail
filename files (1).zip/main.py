"""
Macro Grisa Daily Briefing — main.py
Legge le email di Bloomberg, Barron's, WSJ e genera un briefing HTML via Claude API.
"""

import os
import base64
import re
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import anthropic
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# ─── CONFIG ────────────────────────────────────────────────────────────────────
RECIPIENT_EMAIL  = os.environ.get("RECIPIENT_EMAIL", "grisantelli@gmail.com")
SENDERS_QUERY    = "from:(bloomberg.com OR barrons.com OR wsj.com) newer_than:1d"
MAX_EMAILS       = 20
MAX_CHARS_EMAIL  = 4000          # Caratteri massimi estratti per email
CLAUDE_MODEL     = "claude-haiku-4-5-20251001"   # Veloce ed economico per task automatici
MAX_TOKENS       = 6000


# ─── GMAIL AUTH ─────────────────────────────────────────────────────────────────
def get_gmail_service():
    creds = Credentials(
        token=None,
        refresh_token=os.environ["GMAIL_REFRESH_TOKEN"],
        token_uri="https://oauth2.googleapis.com/token",
        client_id=os.environ["GMAIL_CLIENT_ID"],
        client_secret=os.environ["GMAIL_CLIENT_SECRET"],
        scopes=[
            "https://www.googleapis.com/auth/gmail.readonly",
            "https://www.googleapis.com/auth/gmail.send",
        ],
    )
    creds.refresh(Request())
    return build("gmail", "v1", credentials=creds)


# ─── FETCH & PARSE EMAILS ────────────────────────────────────────────────────────
def fetch_emails(service) -> list[dict]:
    try:
        result = (
            service.users()
            .messages()
            .list(userId="me", q=SENDERS_QUERY, maxResults=MAX_EMAILS)
            .execute()
        )
    except HttpError as e:
        print(f"[WARN] Gmail fetch error: {e}")
        return []

    messages = result.get("messages", [])
    emails = []

    for msg_ref in messages:
        try:
            full = (
                service.users()
                .messages()
                .get(userId="me", id=msg_ref["id"], format="full")
                .execute()
            )
            headers = {
                h["name"]: h["value"]
                for h in full["payload"]["headers"]
            }
            body = _extract_text(full["payload"]) or full.get("snippet", "")
            body = _clean_text(body)[:MAX_CHARS_EMAIL]

            emails.append(
                {
                    "subject": headers.get("Subject", "(no subject)"),
                    "sender":  headers.get("From", ""),
                    "date":    headers.get("Date", ""),
                    "body":    body,
                }
            )
        except Exception as e:
            print(f"[WARN] Skipping message {msg_ref['id']}: {e}")

    return emails


def _extract_text(payload: dict) -> str | None:
    """Estrae ricorsivamente il corpo plain-text dall'email."""
    mime = payload.get("mimeType", "")
    if mime == "text/plain":
        data = payload.get("body", {}).get("data", "")
        if data:
            return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
    for part in payload.get("parts", []):
        result = _extract_text(part)
        if result:
            return result
    return None


def _clean_text(text: str) -> str:
    """Rimuove caratteri invisibili e spazi eccessivi."""
    text = re.sub(r"[\u200c\u200b\u200d\ufeff]", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"https?://\S+", "", text)   # rimuove URL
    return text.strip()


# ─── GENERATE BRIEFING VIA CLAUDE ────────────────────────────────────────────────
def generate_briefing(emails: list[dict]) -> str:
    today_it = datetime.now().strftime("%-d %B %Y")  # es. "18 maggio 2026"
    weekday_map = {
        "Monday": "Lunedì", "Tuesday": "Martedì", "Wednesday": "Mercoledì",
        "Thursday": "Giovedì", "Friday": "Venerdì", "Saturday": "Sabato",
        "Sunday": "Domenica",
    }
    weekday_en = datetime.now().strftime("%A")
    weekday_it = weekday_map.get(weekday_en, weekday_en)

    if emails:
        emails_block = "\n\n".join(
            f"──── {e['sender']} | {e['subject']} | {e['date']} ────\n{e['body']}"
            for e in emails
        )
    else:
        emails_block = "Nessuna email ricevuta da Bloomberg/Barron's/WSJ nelle ultime 24 ore."

    prompt = f"""Sei Macro Grisa, analista macro-finanziario istituzionale italiano.
Analizza le email seguenti (Bloomberg, Barron's, WSJ) e genera un BRIEFING QUOTIDIANO completo in italiano.

DATA: {weekday_it} {today_it}

═══ EMAIL RICEVUTE ═══
{emails_block}
═══════════════════════

Genera un email HTML completa, pronta per essere inviata, rispettando QUESTE REGOLE:

STRUTTURA OBBLIGATORIA:
1. Header Macro Grisa (titolo "MACRO GRISA · BRIEFING QUOTIDIANO", data)
2. Snapshot mercati (tabella con asset chiave e variazioni se disponibili)
3. Sezioni tematiche (almeno 4-6 tra: Macro, Bond/Tassi, Energia/Petrolio,
   Geopolitica, Corporate & M&A, AI & Tecnologia, Agenda Settimana)
4. Sintesi editoriale (3-5 righe di chiusura)
5. Footer con fonti

STILE HTML:
- Sfondo: #0a0e1a (dark navy)
- Testo principale: #e8e8e8
- Accenti oro: #C9913D
- Sezioni con border-left: 3px solid #C9913D
- Tabelle mercati con sfondo #0f1420
- Font: -apple-system, 'Segoe UI', sans-serif
- Max-width: 680px, centrato, padding 24px
- Ogni sezione ha emoji + titolo in maiuscolo
- Dati numerici in grassetto, variazioni positive in #4ade80, negative in #f87171
- Header con gradient da #0a0e1a a #1a1030

REGOLE CONTENUTO:
- Italiano istituzionale, preciso, mai sensazionalistico
- Cita sempre i dati numerici concreti dove presenti nelle email
- Se un tema è coperto da più fonti, sintetizzale in un'unica sezione
- Segnala discrepanze tra le fonti se rilevanti
- La Sintesi Editoriale deve identificare il tema macro dominante del giorno

Restituisci SOLO il codice HTML completo. Nessun testo prima o dopo."""

    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    response = client.messages.create(
        model=CLAUDE_MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


# ─── SEND EMAIL ──────────────────────────────────────────────────────────────────
def send_email(service, html_body: str):
    today_it = datetime.now().strftime("%-d %B %Y")
    subject  = f"🗞 Macro Grisa Briefing — {today_it}"

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = "grisantelli@gmail.com"
    msg["To"]      = RECIPIENT_EMAIL
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    service.users().messages().send(userId="me", body={"raw": raw}).execute()


# ─── ORCHESTRATOR ────────────────────────────────────────────────────────────────
def main():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] ── Macro Grisa Daily Briefing START ──")

    service = get_gmail_service()
    print("  ✓ Gmail autenticato")

    emails = fetch_emails(service)
    print(f"  ✓ {len(emails)} email trovate (Bloomberg/Barrons/WSJ)")

    html = generate_briefing(emails)
    print(f"  ✓ Briefing generato ({len(html):,} chars)")

    send_email(service, html)
    print(f"  ✓ Email inviata a {RECIPIENT_EMAIL}")
    print(f"[{ts}] ── DONE ──")


if __name__ == "__main__":
    main()
